/**
 * src/utils/imageUpload.js
 *
 * Compress + upload images to Firebase Storage.
 * Returns the public download URL for Firestore.
 */

import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { app } from "../config/firebase";

const storage = getStorage(app);

/** Resize to max 800px wide, compress to 80% JPEG quality */
export function compressImage(file) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const MAX_W = 800;
      let w = img.width, h = img.height;
      if (w > MAX_W) { h = Math.round(h * (MAX_W / w)); w = MAX_W; }
      const canvas = document.createElement("canvas");
      canvas.width = w;
      canvas.height = h;
      canvas.getContext("2d").drawImage(img, 0, 0, w, h);
      canvas.toBlob(
        (blob) => blob ? resolve(blob) : reject(new Error("Compression failed")),
        "image/jpeg",
        0.8
      );
      URL.revokeObjectURL(img.src);
    };
    img.onerror = () => reject(new Error("Image load failed"));
    img.src = URL.createObjectURL(file);
  });
}

/** Compress then upload to Firebase Storage, returns download URL */
export async function uploadMenuImage(file) {
  const blob = await compressImage(file);
  const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, "_");
  const storageRef = ref(storage, `menu-images/${Date.now()}_${safeName}`);
  await uploadBytes(storageRef, blob);
  return getDownloadURL(storageRef);
}

/** Upload barcode image (no compression), returns download URL */
export async function uploadBarcodeImage(file) {
  const safeName = file.name.replace(/[^a-zA-Z0-9.]/g, "_");
  const storageRef = ref(storage, `barcode-images/${Date.now()}_${safeName}`);
  await uploadBytes(storageRef, file);
  return getDownloadURL(storageRef);
}
